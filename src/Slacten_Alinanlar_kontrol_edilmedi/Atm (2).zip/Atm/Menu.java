package Atm;

import java.util.Scanner;

public class Menu extends AtmKarsilama {

    static int bakiye = 10000;
    int paraYatirma = 0;
    int paraCekme = 0;
    int paraGonderme = 0;

    String SifreDegistirme = "5- Sifre Degistirme";

    public int getBakiye() {
        System.out.println(bakiye);
        return bakiye;
    }

    Menu() {
        Scanner scan = new Scanner(System.in);
        System.out.println("1- Bakiye" +
                "\n2- Para Yatirma" +
                "\n3- Para Cekme" +
                "\n4- Para Gonderme" +
                "\n5- Sifre Degistirme" +
                "\nYapmak istediginiz islemi giriniz\nSistemden cikis yapmak icin rastgele bir tusa basiniz");
        int secim = scan.nextInt();
        if (secim == 3) {
            setParaCekme(paraCekme);
            new Menu();
        }
        if (secim == 4) {
            setParaGonderme(paraGonderme);

            new Menu();
        }
        if (secim == 1) {
            getBakiye();

            new Menu();
        }
        if (secim == 2) {
            setParaYatirma(paraYatirma);
            new Menu();

        }
        if (secim == 5) {
            setSifreDegistirme();
            new Menu();


        }

    }




    public int getParaYatirma() {

        return bakiye;
    }

    public void setParaYatirma(int paraYatirma) {
        Scanner scan = new Scanner(System.in);
        System.out.println("yatirmak istediginiz tutari giriniz.");
        paraYatirma = scan.nextInt();
        this.bakiye += paraYatirma;
        System.out.println(paraYatirma + "dan sonra hesabinizin bakiyesi" + bakiye);

    }

    public int getParaCekme() {
        bakiye -= paraCekme;
        return bakiye;
    }

    public void setParaCekme(int paraCekme) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Cekmek istediginiz tutari giriniz.");
        paraCekme = scan.nextInt();
        while ((paraCekme > bakiye)) {
            System.out.println("Cekmek istediginzi tutar bakiyenizden yuksektir.");
            System.out.println("Tekra cekmek istediginiz tutari giriniz.");
            paraCekme = scan.nextInt();
        }
        this.bakiye -= paraCekme;
        System.out.println(bakiye);
    }

    public int getParaGonderme() {
        return bakiye - paraGonderme;
    }

    public void setParaGonderme(int paraGonderme) {
        Scanner scan = new Scanner(System.in);
        System.out.println("gondermek istediginiz tutari giriniz.");
        this.paraGonderme = scan.nextInt();
        while ((paraGonderme > bakiye)) {
            System.out.println("Gondermek istediginzi tutar bakiyenizden yuksektir.");
            System.out.println("Tekra gondermek istediginiz tutari giriniz.");
            paraGonderme = scan.nextInt();
        }

        System.out.println(getParaGonderme() + "    ");
        System.out.println("Para gondermek istediginzi Iban numarasini giriniz");


        this.bakiye -= paraGonderme;
    }

    public void setSifreDegistirme() {
        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen sifrenizi giriniz");
        String sifreYa = scan.nextLine();

            if (! sifreYa.equals(AtmKarsilama.getSifreYa())) {
                System.out.println("sifrenizi dogru girdiniz");
                System.out.println("yeni sifrenizi giriniz");
                String yeniSifre= scan.nextLine();
                AtmKarsilama.setSifre(yeniSifre);
                System.out.println("Guvenliginiz icin sistemden cikis yapiliyor.....");

            } else  {
                while ((sifreYa.equals(AtmKarsilama.getSifreYa()))) {
                System.out.println("*****sifreniz yanlis  giriniz*****");
                setSifreDegistirme();
            }

        }

    }
}