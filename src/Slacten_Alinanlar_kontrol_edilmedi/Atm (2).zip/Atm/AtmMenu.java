package Atm;

import java.util.Scanner;

public class AtmMenu {


public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
       AtmKarsilama ob1 = new AtmKarsilama();
       ob1.kart(ob1.kartNo);
       ob1.sifre(ob1.sifre);


        Menu ob2 = new Menu();


    }
}
