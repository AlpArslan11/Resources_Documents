package Atm;

import java.util.Scanner;

public class AtmKarsilama extends AtmMenu {

    protected static String sifre = "sinan";
    protected String kartNo;
    protected String isim;
     protected static String sifreYa;

    public AtmKarsilama() {
        System.out.println("*********Java Bank*********\n*********Hosgeldiniz*********\n");

    }

    public void kart(String kartNo) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen kart numaranizi giriniz");
        kartNo = scan.nextLine();
        kartNo = kartNo.replaceAll("\\D", "");
        if (!(kartNo.length() == 16)) {

        } else {
            System.out.println("sifreniz 16 basamakli ve sadece sayilardan olusmalidir");
            kart(kartNo);
        }
    }

    public static String getSifreYa() {
        return sifreYa;
    }

    public static void setSifre(String sifre) {
        AtmKarsilama.sifre= sifre;
    }

    public void sifre(String sifre) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Lutfen sifrenizi giriniz");
        String sifreYa = scan.next();
        while (!(sifre.equals(sifreYa))) {
            if (sifre.equals(sifreYa)) {
                System.out.println("sifrenizi dogru girdiniz");
            } else {
                System.out.println("*****sifreniz yanlis  giriniz*****");
                sifre(sifre);
            }


        }

    }
}




