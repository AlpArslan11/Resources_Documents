package sinav;

import java.util.List;

public interface SinifOturum {


    int sinifMevcudu=30;

    String sinifBelirleme(List<String> ogr_list,int oturum);
}
