package sinav;

public class Ogrenci {
    String ogr_adi;
    String ogr_ders;
    public Ogrenci(String ogr_adi, String ogr_ders) {
        this.ogr_adi = ogr_adi;
        this.ogr_ders = ogr_ders;
    }


}
