SELECT * FROM deneme.ogrenci where ogr_ad='ali'; -- ali isminde olanlari getirir
SELECT * FROM deneme.ogrenci where ogr_no=3; -- ogrenci numarasi 3 olanlari getirir